<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

		 <link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.min.css">

        <link rel="stylesheet" type="text/css" href="../css/peliculas/peliculas.css">
        <link rel="stylesheet" type="text/css" href="../css/peliculas/responsive.css">

		<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">

    </head>
    <body>

	<table border="0" align="center">

		<tr>
			<td>
				<br>
			</td>
		</tr>

		<tr>
			<td align="center" height="50px" bgcolor="#40E0D0">
					<!-- Pelicuas -->
					<section id="works" class="works clearfix">

						<div class="container">
							<div class="row">
							
								<div class="sec-title text-center">
									<h2 style="color: #000000">Peliculas </h2>
									<br>
									<p>En esta seccion encontraras las peliculas, que puedes reservar </p>
									<div class="devider">Puedes ver online peliculas -> <a href=""> <b>Clic aqui</b></a></div>
								</div>
								
							</div>
						</div>

					</section>
			        <!--Fin Peliculas -->
			
			</td>
		</tr>		

		<tr>
			<td>
				<br>
			</td>
		</tr>

		<tr>
			<td align="center" height="50px" bgcolor="#40E0D0">
					<!-- Pelicuas -->
					<section id="works" class="works clearfix">
						
						<div class="container">
							<div class="row">
							
								<div class="sec-title text-center">
									<h2 style="color: #000000"> ESTRENOS </h2>
								</div>
								
								<div class="row dept_row">
									<div class="col">
										<div class="dept_slider_container_outer">
											<div class="dept_slider_container">
												<div class="owl-carousel owl-theme dept_slider">
													<!--Inicio -->
													<div class="project-wrapper">
														<figure class="mix work-item web" data-wow-duration="500ms">										
															<img src="../imagenes/accion/accion1.jpg" alt="">
															<figcaption class="overlay">
																<a class="fancybox" rel="works" title="Write Your Image Caption Here" href="../imagenes/accion/accion1.jpg"><i class="fa fa-eye fa-lg"></i></a>

																<h4>Fundador en SoftPanG - CEO </h4>
																<p>Maestria en Administrador de Base de datos - Universidad Nacional de Ingenieria</p>
															</figcaption>

															<div class="dept_content">
																<div class="dept_title">Sistema</div>
																<div class="dept_link"><a href="#">Leer mas</a></div>
															</div>
														</figure>
													</div>
													<!--Fin-->
												</div>
											</div>
										</div>
									</div>
								</div>
								
							</div>
						</div>

					</section>
			        <!--Fin Peliculas -->
			</td>
		</tr>					
						

			        		

	</table>	

    	<script src="../js/jquery-1.11.1.min.js"></script>	
        <script src="../js/jquery.singlePageNav.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/count-to.js"></script>
        <script src="../js/jquery.appear.js"></script>
        <script src="../js/owl.carousel.min.js"></script>
        <script src="../js/custom.js"></script>
        <script src="../js/script.js"></script>

        <script src="../js/main.js"></script>
		<script src="../js/jquery-3.3.1.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		
		<script src="../css/bootstrap4/popper.js"></script>
		<script src="../css/bootstrap4/bootstrap.min.js"></script>
		

		<script src="../plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
		<script src="../plugins/easing/easing.js"></script>
		<script src="../plugins/parallax-js-master/parallax.min.js"></script>
		<script src="../js/custom2.js"></script>

    </body>
</html>
