<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title> * Sobre * </title>

        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/bootstrap.css">

        <link rel="stylesheet" href="../css/estilos.css">


    </head>
    <body>
                
        <section class="container">
            <div class="row">
                <div class="col-md-4">

                </div>
                <div class="col-md-4">
                    <p align="Center" style="font-family:Times; font-size: 30px;">
                        * Cine Plac *
                    </p>
                    <p align="justify" style="font-family:Times;">
                        
                        <br>
                        CinePlac , es una tienda dedicada al alquiler de peliculas en cd, 
                        nace el 03 de Septembre del 2018.
                        
                    </p>

                    <p align="justify" style="font-family:Times;">
                        Para diferenciarnos del resto de videoclubes empezamos a crear nuestro archivo “personal”. Primero fue nuestra colección privada, luego poco a poco vimos la necesidad de empezar a crear un archivo videográfico, en donde se guardaban todas las películas que salían y que ya no eran novedad, que se alquilaban menos o que se descatalogaban. 

                        Desde hace tiempo, cuando alguien busca una película sabe que nosotros la tenemos, de hecho, la frase que se oye de nuestros clientes es: “si no está aquí, es que no está “.
                    </p>    
                    <p align="center" style="font-family:Times;">
                        <img src="../imagenes/Banner/banner2.jpg" alt="" width="370px" height="250px">
                    </p>    
                </div>

                <div class="col-md-4">
                    
                </div>
            </div>
        </section>
    </body>
</html>
